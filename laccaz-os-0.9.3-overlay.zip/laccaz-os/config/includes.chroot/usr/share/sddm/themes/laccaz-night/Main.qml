import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: root
    width: 1440; height: 900
    color: "#101216"
    property bool busy: false
    property bool compact: height < 760
    property string message: ""
    property date now: new Date()
    function submit() {
        if (busy) return
        var account = user.editText.trim()
        if (!account || session.currentIndex < 0) {
            message = "Укажи пользователя и выбери сеанс."
            return
        }
        message = ""; busy = true
        sddm.login(account, password.text, session.currentIndex)
    }
    Timer { interval: 1000; running: true; repeat: true; onTriggered: root.now = new Date() }
    gradient: Gradient { GradientStop { position: 0; color: "#0e1015" } GradientStop { position: 1; color: "#30343d" } }
    Canvas {
        anchors.fill: parent
        onPaint: {
            var c = getContext("2d"); c.clearRect(0,0,width,height)
            var glow = c.createRadialGradient(width*.18,height*.8,0,width*.18,height*.8,width*.7)
            glow.addColorStop(0,"#172d45");glow.addColorStop(1,"transparent");c.fillStyle=glow;c.fillRect(0,0,width,height)
            c.lineWidth=1
            for(var n=0;n<9;n++) {
                c.strokeStyle="rgba(180,200,230,"+(0.02+n*.003)+")";c.beginPath()
                c.moveTo(-100,height*.2+n*26);c.bezierCurveTo(width*.3,height*.9+n*22,width*.7,-height*.2+n*24,width+100,height*.5+n*28);c.stroke()
            }
        }
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
    }
    Text { anchors.top: parent.top; anchors.right: parent.right; anchors.margins: 26; text: Qt.formatDateTime(root.now,"hh:mm"); color: "#9099a9"; font.pixelSize: 13 }
    Rectangle {
        id: card
        anchors.centerIn: parent
        width: Math.min(470,root.width-36);height: form.implicitHeight+72
        scale: Math.min(1,(root.height-100)/height)
        radius: 26; color: "#ed1b1e25"; border.color: "#343a45";border.width: 1
        Rectangle { anchors.top: parent.top; anchors.horizontalCenter: parent.horizontalCenter; width: parent.width*.7;height: 1; color: "#596476"; opacity: .35 }
        ColumnLayout {
            id: form
            anchors.centerIn: parent; width: parent.width-72; spacing: 12
            Item {
                Layout.preferredHeight: 66;Layout.fillWidth: true
                Image { x: 0;y: 0;width: 50;height: 50;source: "../../../laccaz/logo.svg";smooth: true }
                Text { anchors.right: parent.right;y: 17;text: "LACCAZ OS";font.pixelSize: 11;font.letterSpacing: 2;color: "#8995a9" }
            }
            Text { text: "Добро пожаловать в Laccaz";color: "#f2f4f8";font.pixelSize: 23;font.weight: Font.Medium;Layout.fillWidth: true;wrapMode: Text.WordWrap }
            Text { text: "Войди, чтобы продолжить";color: "#8895a9";font.pixelSize: 13;Layout.bottomMargin: 12 }
            Label { text: "Пользователь";color: "#aeb7c6";font.pixelSize: 12 }
            NightCombo {
                id: user;objectName: "loginUser";Layout.fillWidth: true;implicitHeight: 44
                model: userModel;textRole: "name";editable: true;currentIndex: Math.max(0,userModel.lastIndex);enabled: !root.busy
                Component.onCompleted: editText = userModel.lastUser || currentText
                onActivated: password.forceActiveFocus()
                palette.base: "#242832";palette.text: "#edf1f8";palette.buttonText: "#edf1f8";palette.highlight: "#3f699e"
            }
            Label { text: "Пароль";color: "#aeb7c6";font.pixelSize: 12 }
            TextField {
                id: password;objectName: "loginPassword";Layout.fillWidth: true;implicitHeight: 44
                echoMode: reveal.checked ? TextInput.Normal : TextInput.Password
                placeholderText: "Введи пароль";enabled: !root.busy;color: "#edf1f8";placeholderTextColor: "#727f92";selectByMouse: true;rightPadding: 48
                background: Rectangle { radius: 8;color: "#252933";border.color: root.message ? "#ba6f78" : (password.activeFocus ? "#6294d4" : "#3a414e") }
                onAccepted: root.submit()
                Component.onCompleted: forceActiveFocus()
                Button {
                    id: reveal;objectName: "revealPassword";checkable: true;anchors.right: parent.right;anchors.verticalCenter: parent.verticalCenter;width: 40;height: 40;enabled: !root.busy
                    Accessible.name: checked ? "Скрыть пароль" : "Показать пароль"
                    background: Rectangle { color: "transparent" }
                    contentItem: Text { text: reveal.checked ? "◉" : "◎";color: "#9aaac2";font.pixelSize: 19;horizontalAlignment: Text.AlignHCenter;verticalAlignment: Text.AlignVCenter }
                }
            }
            Text { objectName: "loginMessage";text: root.message;color: "#ec9a9f";Layout.fillWidth: true;wrapMode: Text.WordWrap;font.pixelSize: 12;visible: text.length>0 }
            Button {
                objectName: "loginButton";Layout.fillWidth: true;Layout.topMargin: 12;implicitHeight: 48;enabled: !root.busy
                text: root.busy ? "Вход…" : "Войти"
                contentItem: Text { text: parent.text;color: "#ffffff";font.pixelSize: 14;font.weight: Font.Medium;horizontalAlignment: Text.AlignHCenter;verticalAlignment: Text.AlignVCenter }
                background: Rectangle { radius: 9;color: parent.down ? "#356dc4" : "#477fe3";opacity: parent.enabled ? 1 : .6 }
                onClicked: root.submit()
            }
            Button {
                id: options;objectName: "loginOptions";checkable: true;text: checked ? "Скрыть параметры" : "Параметры входа";Layout.alignment: Qt.AlignHCenter
                background: Rectangle { color: "transparent" }
                contentItem: Text { text: parent.text;color: "#8d9ab0";font.pixelSize: 11;horizontalAlignment: Text.AlignHCenter }
            }
            RowLayout {
                visible: options.checked;Layout.fillWidth: true;spacing: 10
                NightCombo {
                    id: session;objectName: "loginSession";model: sessionModel;textRole: "name";currentIndex: sessionModel.lastIndex
                    Layout.fillWidth: true;implicitHeight: 40;enabled: !root.busy
                    palette.base: "#242832";palette.buttonText: "#edf1f8";palette.text: "#edf1f8"
                }
                NightCombo {
                    objectName: "loginLayout";visible: keyboard.enabled && keyboard.layouts.length>0;model: keyboard.layouts;textRole: "shortName";currentIndex: keyboard.currentLayout
                    implicitWidth: 76;implicitHeight: 40;onActivated: keyboard.currentLayout=currentIndex
                    palette.base: "#242832";palette.buttonText: "#edf1f8";palette.text: "#edf1f8"
                }
            }
        }
    }
    Row {
        anchors.bottom: parent.bottom;anchors.horizontalCenter: parent.horizontalCenter;anchors.bottomMargin: 20;spacing: 12
        NightButton { objectName: "rebootButton";text: "Перезапуск";visible: sddm.canReboot;enabled: !root.busy;onClicked: { powerConfirm.action="reboot";powerConfirm.open() } }
        NightButton { objectName: "powerButton";text: "Выключить";visible: sddm.canPowerOff;enabled: !root.busy;onClicked: { powerConfirm.action="off";powerConfirm.open() } }
    }
    component NightCombo: ComboBox {
        id: control
        contentItem: TextField {
            text: control.editable ? control.editText : control.displayText
            readOnly: !control.editable;enabled: control.editable;selectByMouse: control.editable
            color: "#e2e7f0";font.pixelSize: 13;leftPadding: 12;rightPadding: 30
            verticalAlignment: TextInput.AlignVCenter
            background: Item {}
            onTextEdited: control.editText = text
        }
        background: Rectangle { color: "#242c38"; radius: 7; border.color: parent.activeFocus ? "#91b4e8" : "#414c5e" }
        indicator: Text { text: "⌄"; color: "#c3cfdf"; font.pixelSize: 18; anchors.right: parent.right; anchors.rightMargin: 12; anchors.verticalCenter: parent.verticalCenter }
    }
    component NightButton: Button {
        implicitHeight: 36
        background: Rectangle { color: parent.down ? "#40516b" : "#293342"; radius: 6; border.color: "#46536a" }
        contentItem: Text { text: parent.text; color: "#d5dfed"; font.pixelSize: 12; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter }
    }
    Dialog {
        id: powerConfirm
        property string action: ""
        anchors.centerIn: parent
        title: action === "reboot" ? "Перезагрузить компьютер?" : "Выключить компьютер?"
        modal: true; standardButtons: Dialog.Ok | Dialog.Cancel
        palette.window: "#242c38"; palette.windowText: "#edf1f8"; palette.button: "#303b4d"; palette.buttonText: "#edf1f8"
        onAccepted: action === "reboot" ? sddm.reboot() : sddm.powerOff()
    }
    Connections {
        target: sddm
        function onLoginFailed() {
            root.busy = false; root.message = "Не удалось войти. Проверь пользователя, пароль и раскладку."
            password.clear(); reveal.checked = false; password.forceActiveFocus()
        }
        function onLoginSucceeded() { password.clear(); reveal.checked = false }
    }
}
