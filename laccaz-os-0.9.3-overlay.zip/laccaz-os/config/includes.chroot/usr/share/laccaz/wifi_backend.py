"""NetworkManager worker. Password travels on stdin/DBus, never in argv or logs."""
import json,os,subprocess,sys,time

def fields(line):
 result=[];part='';escaped=False
 for ch in line:
  if escaped:part+=ch;escaped=False
  elif ch=='\\':escaped=True
  elif ch==':':result.append(part);part=''
  else:part+=ch
 result.append(part);return result

def scan():
 env=dict(os.environ,LC_ALL='C')
 p=subprocess.run(['nmcli','--terse','--escape','yes','--fields','IN-USE,SSID,SIGNAL,SECURITY,BSSID','device','wifi','list','--rescan','yes'],capture_output=True,text=True,timeout=25,env=env)
 if p.returncode:raise RuntimeError('Не удалось найти сети. Проверь, включён ли Wi-Fi и доступен ли адаптер. '+p.stderr.strip()[:220])
 rows=[];seen=set()
 for line in p.stdout.splitlines():
  f=fields(line)
  if len(f)!=5 or not f[1] or f[4] in seen:continue
  seen.add(f[4]);rows.append(dict(active=f[0]=='*',ssid=f[1],signal=int(f[2]) if f[2].isdigit() else 0,security=f[3],bssid=f[4]))
 return sorted(rows,key=lambda a:(not a['active'],-a['signal']))

def connect(request):
 import dbus
 bus=dbus.SystemBus();service='org.freedesktop.NetworkManager';props='org.freedesktop.DBus.Properties'
 nm=dbus.Interface(bus.get_object(service,'/org/freedesktop/NetworkManager'),service)
 selected=None
 for dev in nm.GetDevices():
  obj=bus.get_object(service,dev);p=dbus.Interface(obj,props)
  if int(p.Get(service+'.Device','DeviceType'))!=2:continue
  wifi=dbus.Interface(obj,service+'.Device.Wireless')
  for ap in wifi.GetAllAccessPoints():
   info=dbus.Interface(bus.get_object(service,ap),props)
   if str(info.Get(service+'.AccessPoint','HwAddress')).upper()==request['bssid'].upper():selected=(dev,ap);break
  if selected:break
 if not selected:raise RuntimeError('Сеть больше не видна. Обнови список и попробуй снова.')
 device,ap=selected;settings=dbus.Interface(bus.get_object(service,'/org/freedesktop/NetworkManager/Settings'),service+'.Settings')
 profile=None;existing=None
 for path in settings.ListConnections():
  candidate=dbus.Interface(bus.get_object(service,path),service+'.Settings.Connection');data=candidate.GetSettings()
  if data.get('connection',{}).get('type')=='802-11-wireless' and bytes(data.get('802-11-wireless',{}).get('ssid',b''))==request['ssid'].encode('utf-8'):
   profile=path;existing=(candidate,data);break
 password=request.get('password','');security=request.get('security','')
 if '802.1X' in security:raise RuntimeError('Корпоративная сеть: открой «Дополнительные настройки» для сертификатов и учётной записи.')
 if profile:
  if password:
   candidate,data=existing;sec=data.setdefault('802-11-wireless-security',dbus.Dictionary(signature='sv'));sec['psk']=password;candidate.Update(data)
  active=nm.ActivateConnection(profile,device,ap)
 else:
  data={'connection':{'id':request['ssid'],'type':'802-11-wireless','autoconnect':dbus.Boolean(True)},'802-11-wireless':{'ssid':dbus.ByteArray(request['ssid'].encode()),'mode':'infrastructure'},'ipv4':{'method':'auto'},'ipv6':{'method':'auto'}}
  if security and security!='--':
   if not password:raise RuntimeError('Для первого подключения введи пароль сети.')
   if 'WEP' in security:raise RuntimeError('Для WEP используй дополнительные настройки.')
   key='sae' if 'WPA3' in security and 'WPA2' not in security else 'wpa-psk'
   data['802-11-wireless-security']={'key-mgmt':key,'psk':password}
  typed=dbus.Dictionary({k:dbus.Dictionary(v,signature='sv') for k,v in data.items()},signature='sa{sv}')
  profile,active=nm.AddAndActivateConnection(typed,device,ap)
 state=dbus.Interface(bus.get_object(service,active),props)
 for _ in range(150):
  value=int(state.Get(service+'.Connection.Active','State'))
  if value==2:return {'connected':True}
  if value==4:raise RuntimeError('Подключение не удалось. Проверь пароль и повтори попытку.')
  time.sleep(.3)
 raise RuntimeError('Подключение не завершилось вовремя. Проверь пароль, сигнал и настройки сети.')

if __name__=='__main__':
 try:
  if sys.argv[1:]==['scan']:result=scan()
  elif sys.argv[1:]==['connect']:result=connect(json.loads(sys.stdin.read(16384)))
  else:raise RuntimeError('Неизвестное действие.')
  print(json.dumps({'ok':True,'data':result},ensure_ascii=False))
 except Exception as error:
  # DBus errors can contain settings data; never echo their messages.
  message=str(error) if isinstance(error,RuntimeError) else 'NetworkManager не выполнил запрос. Проверь адаптер, пароль и разрешения подключения.'
  print(json.dumps({'ok':False,'error':message},ensure_ascii=False));sys.exit(1)
