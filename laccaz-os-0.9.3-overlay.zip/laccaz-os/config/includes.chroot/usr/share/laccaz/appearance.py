from PySide6.QtCore import Qt,QRectF,QSize,QPropertyAnimation,QEasingCurve
from PySide6.QtGui import QColor,QPainter,QPen,QPixmap,QIcon,QLinearGradient
from PySide6.QtWidgets import QWidget,QHBoxLayout,QPushButton,QLabel,QAbstractButton
STYLE="""
QWidget{background:#171e2a;color:#e6edf7;font-family:Noto Sans;font-size:13px}
QLabel{background:transparent} QLabel#brand{font-size:24px;font-weight:700;color:#f1f3f4}
QLabel#hero{font-size:28px;font-weight:700} QLabel#muted{color:#a4abb6}
QWidget#sidebar{background:#1d2838;border-radius:10px} QWidget#card{background:#233146;border:1px solid #3b3e45;border-radius:10px}
QPushButton{background:#233146;border:1px solid #34455d;border-radius:11px;padding:11px 15px;text-align:left}
QPushButton:hover{background:#3c414b;border-color:#647b9b} QPushButton:pressed{background:#465267}
QPushButton#primary{background:#5a89c9;color:#ffffff;border:0;font-weight:600} QPushButton#primary:hover{background:#7098cf}
QLineEdit,QComboBox{background:#233146;border:1px solid #444850;border-radius:11px;padding:12px;selection-background-color:#49678f}
QPlainTextEdit{background:#101722;color:#dce2ec;border:0;border-radius:14px;padding:14px;font-family:monospace}
QListWidget{background:#233146;border:1px solid #34455d;border-radius:9px;padding:9px}
QListWidget::item{padding:15px;border-bottom:1px solid #34373d}
QListWidget::item:selected{background:#365276;color:#dbe9ff;border-radius:8px}
QTabWidget::pane{background:#1a2535;border:1px solid #34455d;border-radius:14px} QTabBar::tab{background:#1d2838;padding:10px 20px;margin:3px;border-radius:8px} QTabBar::tab:selected{background:#233146;color:#a3c8ff} QGroupBox{background:#233146;border:1px solid #3b3e45;border-radius:10px;margin-top:16px;padding:20px}
QGroupBox::title{subcontrol-origin:margin;left:20px;padding:0 6px}
QCheckBox{padding:9px} QScrollBar:vertical{width:9px;background:transparent} QScrollBar::handle:vertical{background:#5c626d;border-radius:4px;min-height:25px}
"""
class WindowButton(QAbstractButton):
 def __init__(self,kind,parent=None):
  super().__init__(parent);self.kind=kind;self.setFixedSize(36,36);self.setCursor(Qt.PointingHandCursor)
  self.setToolTip({'close':'Закрыть','minimize':'Свернуть','maximize':'Развернуть / восстановить'}[kind]);self.setAccessibleName(self.toolTip());self.setObjectName('window_'+kind)
 def paintEvent(self,event):
  p=QPainter(self);p.setRenderHint(QPainter.Antialiasing)
  color='#41444b' if self.underMouse() else '#33353a'
  p.setBrush(QColor(color).darker(112) if self.isDown() else QColor(color));p.setPen(Qt.NoPen);p.drawEllipse(QRectF(6,6,24,24))
  p.setPen(QPen(QColor('#e3e6eb'),1.8))
  if self.kind=='close':p.drawLine(14,14,22,22);p.drawLine(14,22,22,14)
  elif self.kind=='minimize':p.drawLine(13,18,23,18)
  else:p.drawRect(14,14,8,8)
  p.end()
class Titlebar(QWidget):
 def __init__(self,window,title):
  super().__init__();self.target=window;row=QHBoxLayout(self);row.setContentsMargins(0,0,8,0);row.setSpacing(2);self.setMinimumHeight(44)
  self.buttons={};label=QLabel(title);label.setAttribute(Qt.WA_TransparentForMouseEvents);row.addWidget(label);row.addStretch()
  for kind,fn in [('minimize',self.minimize),('maximize',self.zoom),('close',self.close_target)]:
   button=WindowButton(kind);button.clicked.connect(lambda checked=False,action=fn:action());row.addWidget(button);self.buttons[kind]=button
 def close_target(self):self.target.close()
 def minimize(self):self.target.showMinimized()
 def zoom(self):self.target.showNormal() if self.target.isMaximized() else self.target.showMaximized()
 def mousePressEvent(self,event):
  if event.button()==Qt.LeftButton and self.target.windowHandle():self.target.windowHandle().startSystemMove()
 def mouseDoubleClickEvent(self,event):
  if event.button()==Qt.LeftButton:self.zoom()

def dock_icon(kind,index):
 pix=QPixmap(48,48);pix.fill(Qt.transparent);p=QPainter(pix);p.setRenderHint(QPainter.Antialiasing)
 p.setPen(QPen(QColor('#dce4f0'),2.3));p.setBrush(Qt.NoBrush)
 if index==0:
  for x in (13,24,35):
   for y in (13,24,35):p.drawEllipse(x-2,y-2,4,4)
 elif index==1:
  p.drawLine(18,14,10,24);p.drawLine(10,24,18,34);p.drawLine(30,14,38,24);p.drawLine(38,24,30,34);p.drawLine(27,11,21,37)
 elif index==2:
  p.drawRoundedRect(9,16,31,23,3,3);p.drawLine(10,16,10,11);p.drawLine(10,11,23,11);p.drawLine(23,11,28,16)
 elif index==3:
  p.drawLine(12,15,21,23);p.drawLine(21,23,12,31);p.drawLine(25,33,36,33)
 elif index==4:
  p.drawRoundedRect(12,11,25,29,3,3);p.drawRoundedRect(19,8,11,7,2,2);p.drawLine(18,24,31,24);p.drawLine(18,31,31,31)
 elif index==5:
  p.drawRoundedRect(8,10,25,22,3,3);p.drawRoundedRect(16,20,25,20,3,3)
 elif index==7:
  p.drawEllipse(9,9,30,30);p.drawEllipse(18,9,12,30);p.drawLine(9,24,39,24)
 else:
  p.drawLine(12,34,24,11);p.drawLine(24,11,36,34);p.drawLine(10,28,38,28);p.drawLine(19,11,31,34)
 p.end();return QIcon(pix)

def monochrome_icon(icon):
 pix=icon.pixmap(QSize(48,48))
 if pix.isNull():return icon
 p=QPainter(pix);p.setCompositionMode(QPainter.CompositionMode_SourceIn);p.fillRect(pix.rect(),QColor('#e5ebf5'));p.end()
 return QIcon(pix)

class DockButton(QPushButton):
 def __init__(self,icon,tip):
  super().__init__();self.running=False;self.setIcon(monochrome_icon(icon));self.setIconSize(QSize(24,24));self.setFixedSize(38,36);self.setToolTip(tip);self.setAccessibleName(tip);self.setCursor(Qt.PointingHandCursor)
  self.setStyleSheet('QPushButton{background:transparent;border:0;padding:0;border-radius:5px} QPushButton:hover{background:rgba(140,170,210,24)} QPushButton:pressed{background:rgba(140,170,210,42)}')
 def paintEvent(self,event):
  super().paintEvent(event)
  if self.running:
   p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);p.setPen(Qt.NoPen);p.setBrush(QColor('#65aeff'));p.drawRoundedRect(QRectF(self.width()/2-9,self.height()-3,18,2),1,1);p.end()
