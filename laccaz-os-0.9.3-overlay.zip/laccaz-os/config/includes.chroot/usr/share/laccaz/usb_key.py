#!/usr/bin/python3
"""Opt-in SDDM USB file factor. Password authentication remains in PAM."""
import hashlib,hmac,json,os,pwd,re,secrets,stat,subprocess,sys,tempfile
from pathlib import Path
CONFIG=Path('/etc/laccaz-usb-keys.json')
PAM_LINE='account required pam_exec.so quiet seteuid /usr/bin/laccaz-usb-key check\n'
ENV={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin','LC_ALL':'C'}
def run(*args):return subprocess.check_output(args,env=ENV,text=True,timeout=12,stderr=subprocess.DEVNULL)
def partitions():
 tree=json.loads(run('/usr/bin/lsblk','--json','--paths','-o','NAME,TYPE,TRAN,UUID'))['blockdevices'];out=[]
 def walk(nodes,usb=False):
  for n in nodes:
   u=usb or n.get('tran')=='usb'
   if u and n.get('uuid') and n.get('type') in ('part','disk'):out.append(n)
   walk(n.get('children',[]),u)
 walk(tree);return out
class Mounted:
 def __init__(self,device,write=False):self.device=device;self.write=write
 def __enter__(self):
  self.path=Path(tempfile.mkdtemp(prefix='laccaz-usb-',dir='/run'))
  try:run('/usr/bin/mount','-o',('rw' if self.write else 'ro')+',nosuid,nodev,noexec',self.device,str(self.path))
  except Exception:self.path.rmdir();raise
  return self.path
 def __exit__(self,*args):
  run('/usr/bin/umount',str(self.path));self.path.rmdir()
def read_key(path):
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
 with os.fdopen(fd,'rb') as f:
  if not stat.S_ISREG(os.fstat(f.fileno()).st_mode):raise ValueError('Not a regular key file')
  data=f.read(129)
  if len(data)!=64:raise ValueError('Invalid key length')
  return data
def valid(data,record):return hmac.compare_digest(hashlib.sha256(data).hexdigest(),record['sha256'])
def verify(record):
 for n in partitions():
  if n['uuid']!=record['uuid']:continue
  try:
   with Mounted(n['name']) as root:
    if valid(read_key(root/record['file']),record):return True
  except Exception:continue
 return False
def load():return json.loads(CONFIG.read_text()) if CONFIG.exists() else {}
def save(records):
 tmp=CONFIG.with_suffix('.tmp');fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'w') as f:json.dump(records,f);f.flush();os.fsync(f.fileno())
 os.replace(tmp,CONFIG)
def main():
 if os.geteuid()!=0:raise ValueError('Run with sudo')
 args=sys.argv[1:]
 if args==['check']:
  user=os.environ.get('PAM_USER','');records=load()
  return 0 if user not in records or verify(records[user]) else 1
 if len(args)==2 and args[0]=='disable':
  records=load();records.pop(args[1],None);save(records);print('USB requirement disabled for '+args[1]);return 0
 if len(args)!=3 or args[0]!='enroll':raise ValueError('Usage: sudo laccaz-usb-key enroll USER /dev/sdX1 | disable USER')
 user,device=args[1:];pwd.getpwnam(user)
 if not re.fullmatch(r'[a-zA-Z0-9_-]+',user):raise ValueError('Unsupported user name')
 nodes=[n for n in partitions() if n['name']==device]
 if len(nodes)!=1:raise ValueError('Select a filesystem partition on a USB device')
 if user in load():raise ValueError('Already enrolled; disable the old key first')
 record={'uuid':nodes[0]['uuid'],'file':'.laccaz-'+secrets.token_hex(12)+'.key'};key=secrets.token_bytes(64);record['sha256']=hashlib.sha256(key).hexdigest()
 with Mounted(device,True) as root:
  fd=os.open(root/record['file'],os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  with os.fdopen(fd,'wb') as f:f.write(key);f.flush();os.fsync(f.fileno())
 if not verify(record):raise ValueError('USB read-back failed; login configuration unchanged')
 # Install the account check before registering this user. Failure leaves no active requirement.
 for service in ('sddm','sddm-autologin'):
  p=Path('/etc/pam.d')/service
  if not p.exists():continue
  text=p.read_text()
  if PAM_LINE not in text:
   backup=p.with_name(service+'.laccaz-before-usb')
   if not backup.exists():backup.write_text(text)
   p.write_text(PAM_LINE+text)
 records=load();records[user]=record;save(records)
 print('Enabled for '+user+'. Keep this session open; test another login with and without USB. Recovery: Ctrl+Alt+F3, password login, sudo laccaz-usb-key disable '+user)
 return 0
if __name__=='__main__':
 try:sys.exit(main())
 except Exception as e:
  if sys.argv[1:]!=['check']:print(str(e),file=sys.stderr)
  sys.exit(1)
