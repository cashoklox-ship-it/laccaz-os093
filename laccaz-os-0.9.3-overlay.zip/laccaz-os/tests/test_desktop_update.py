import os,sys,tempfile,hashlib
from pathlib import Path
from unittest.mock import patch
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt,QMimeData,QUrl
from PySide6.QtTest import QTest
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'config/includes.chroot/usr/share/laccaz'))
from devhub import Hub
from desktop_files import DesktopFiles
import usb_key as usb
app=QApplication([])
h=Hub();h.show();app.processEvents();assert h.isVisible();h.close()
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp);desktop=root/'Desktop';desktop.mkdir();incoming=root/'code.py';incoming.write_text('print(42)')
 with patch('desktop_files.QStandardPaths.writableLocation',return_value=str(desktop)):
  v=DesktopFiles(None);v.resize(700,500);v.show();QTest.qWait(100)
  mime=QMimeData();mime.setUrls([QUrl.fromLocalFile(str(incoming))])
  assert v.fs.dropMimeData(mime,Qt.CopyAction,-1,-1,v.rootIndex());QTest.qWait(150)
  assert (desktop/'code.py').read_text()=='print(42)' and incoming.exists()
  moving=root/'move.txt';moving.write_text('move me');mime.setUrls([QUrl.fromLocalFile(str(moving))]);assert v.fs.dropMimeData(mime,Qt.MoveAction,-1,-1,v.rootIndex());QTest.qWait(100);assert (desktop/'move.txt').exists() and not moving.exists()
  with patch('desktop_files.QInputDialog.getText',return_value=('Notes',True)):v.create(True)
  assert (desktop/'Notes').is_dir()
  with patch('desktop_files.QInputDialog.getText',return_value=('../escape',True)),patch('desktop_files.QMessageBox.warning'):v.create()
  assert not (root/'escape').exists()
  i=v.fs.index(str(desktop/'code.py'));assert v.fs.setData(i,'renamed.py',Qt.EditRole);QTest.qWait(100);assert (desktop/'renamed.py').exists()
  v.close()
 key=b'x'*64;record={'uuid':'123','file':'key','sha256':hashlib.sha256(key).hexdigest()};p=root/'key';p.write_bytes(key)
 assert usb.valid(usb.read_key(p),record);assert not usb.valid(b'y'*64,record)
 link=root/'symlink';link.symlink_to(p)
 try:usb.read_key(link);raise AssertionError('symlink allowed')
 except OSError:pass
 with patch.object(usb,'partitions',return_value=[]):assert not usb.verify(record)
 with patch.object(usb,'run',return_value='{"blockdevices":[{"name":"/dev/sda","type":"disk","tran":"sata","uuid":"123"},{"name":"/dev/sdb","type":"disk","tran":"usb","children":[{"name":"/dev/sdb1","type":"part","uuid":"456"}]}]}'):
  assert [n['name'] for n in usb.partitions()]==['/dev/sdb1']
 with patch.object(usb,'CONFIG',root/'config.json'):
  usb.save({'alice':record});assert usb.load()['alice']==record;assert (root/'config.json').stat().st_mode&0o777==0o600
print('PASS Dev Hub startup; desktop copy/create/rename/path validation; USB hash, missing device, symlink rejection, USB transport filtering, private registry')
