import sys,tempfile,json
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
from PySide6.QtWidgets import QApplication,QToolButton
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'config/includes.chroot/usr/share/laccaz'))
import wifi_backend as backend
assert backend.fields(r'*:Cafe\: space:82:WPA2:00\:11\:22\:33\:44\:55')==['*','Cafe: space','82','WPA2','00:11:22:33:44:55']
with patch.object(backend.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout=r'*:Cafe\: space:82:WPA2:00\:11\:22\:33\:44\:55'+'\n',stderr='')):
 assert backend.scan()[0]['ssid']=='Cafe: space'
class NM:
 def GetDevices(self):return ['/device']
 def AddAndActivateConnection(self,data,device,ap):self.data=data;return '/profile','/active'
 def ActivateConnection(self,*args):raise AssertionError('unexpected saved profile')
nm=NM()
class Props:
 def __init__(self,path):self.path=path
 def Get(self,interface,name):return {'DeviceType':2,'HwAddress':'00:11:22:33:44:55','State':2}[name]
class Wireless:
 def GetAllAccessPoints(self):return ['/ap']
class Settings:
 def ListConnections(self):return []
class Bus:
 def get_object(self,service,path):return path
def interface(path,name):
 if name=='org.freedesktop.DBus.Properties':return Props(path)
 if name.endswith('.Wireless'):return Wireless()
 if name.endswith('.Settings'):return Settings()
 return nm
fake=SimpleNamespace(SystemBus=Bus,Interface=interface,Dictionary=lambda d=None,**kwargs:dict(d or {}),ByteArray=bytes,Boolean=bool)
with patch.dict(sys.modules,{'dbus':fake}):
 assert backend.connect(dict(ssid='Cafe: space',bssid='00:11:22:33:44:55',security='WPA2',password='test-password'))['connected']
 assert nm.data['ipv4']['method']=='auto' and nm.data['ipv6']['method']=='auto'
 assert nm.data['802-11-wireless-security']['psk']=='test-password'
print('PASS Wi-Fi escaped names, scan parsing and mocked NetworkManager DHCP/PSK activation')
from menus import ApplicationMenu,ControlMenu
from appearance import STYLE
app=QApplication([]);app.setStyleSheet(STYLE)
with tempfile.TemporaryDirectory() as d:
 a=Path(d)/'a.desktop';a.write_text('[Desktop Entry]\nType=Application\nName=Code Editor\nCategories=Development;\nIcon=none\n')
 b=Path(d)/'b.desktop';b.write_text('[Desktop Entry]\nType=Application\nName=Browser\nCategories=Network;\nIcon=none\n')
 calls=[];m=ApplicationMenu(lambda:[('Code Editor',str(a)),('Browser',str(b))],lambda *args:calls.append(args) or True);m.resize(810,600);m.reload();m.show();QTest.qWait(30)
 m.filter('Разработка');assert m.count.text()=='1';m.search.setText('missing');assert m.count.text()=='0';m.search.clear();QTest.qWait(10)
 button=m.grid.itemAt(0).widget();QTest.mouseClick(button,Qt.LeftButton);assert calls==[('gio',['launch',str(a)])] and not m.isVisible()
 m.show();QTest.keyClick(m,Qt.Key_Escape);assert not m.isVisible()
c=ControlMenu(lambda *args:True,lambda:None);c.show();QTest.keyClick(c,Qt.Key_Escape);assert not c.isVisible();assert c.windowType()==Qt.Popup
assert not c.findChildren(type(button)) # No window titlebar buttons.
c.shutdown();print('PASS launcher categories/search/actual click, Escape dismissal and popup control menu')
