"""Native X11+Openbox+picom integration: maximize, live transparency and hit testing."""
import sys,subprocess
from pathlib import Path
from PySide6.QtWidgets import QApplication,QWidget
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'config/includes.chroot/usr/share/laccaz'))
from shell import Shell
from appearance import STYLE
app=QApplication([]);app.setStyleSheet(STYLE);app.setQuitOnLastWindowClosed(False);s=Shell(preview=True);s.properties();QTest.qWait(700)
w=QWidget();w.setWindowTitle('Laccaz overlay test');w.setStyleSheet('background:#a04060');w.showMaximized();QTest.qWait(800)
geo=app.primaryScreen().geometry();assert w.frameGeometry().bottom()==geo.bottom(),(w.frameGeometry(),geo)
work=subprocess.check_output(['xprop','-root','_NET_WORKAREA'],text=True);assert f'0, 32, {geo.width()}, {geo.height()-32}' in work,work
# Click app then ensure the dock remains above it, not merely above desktop.
w.raise_();w.activateWindow();s.position_panel();QTest.qWait(600)
button=s.pins[0][1];p=button.mapToGlobal(button.rect().center());subprocess.run(['xdotool','mousemove',str(p.x()),str(p.y()),'click','1'],check=True);QTest.qWait(200);assert s.launcher.isVisible();s.launcher.hide();QTest.qWait(400)
# Transparent space in the dock must reveal the actual app, not wallpaper or a black rectangle.
p=s.panel.mapToGlobal(s.panel.rect().topLeft());img=app.primaryScreen().grabWindow(0).toImage();c=img.pixelColor(p.x()+2,p.y()+2);assert abs(c.red()-160)<5 and abs(c.green()-64)<5 and abs(c.blue()-96)<5,c.name()
from devhub import Hub
w.close();h=Hub();h.showMaximized();QTest.qWait(500);s.position_panel();QTest.qWait(400)
app.primaryScreen().grabWindow(0).save(str(r/'previews/overlay-093.png'));h.close();s.cleanup_tasks();print('PASS X11/Openbox: maximized frame reaches bottom edge; only 32px top workarea reserved; dock clickable over app; live app color visible through transparent panel')
